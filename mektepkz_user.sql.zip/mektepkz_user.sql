-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Май 11 2022 г., 12:59
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `mektepkz_user`
--

-- --------------------------------------------------------

--
-- Структура таблицы `admins`
--
-- Создание: Апр 14 2022 г., 18:15
-- Последнее обновление: Май 07 2022 г., 08:52
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `patronymic` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `iin` varchar(12) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `last_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `admins`
--

INSERT INTO `admins` (`id`, `patronymic`, `firstname`, `lastname`, `mail`, `password`, `iin`, `phone`, `last_time`) VALUES
(1, 'admin', 'ad', 'min', 'admin@gmail.com', 'qwerty123456', '010215500123', '87762492000', '2022-05-07 11:52:59');

-- --------------------------------------------------------

--
-- Структура таблицы `chats`
--
-- Создание: Апр 14 2022 г., 18:15
--

DROP TABLE IF EXISTS `chats`;
CREATE TABLE `chats` (
  `id` int(11) NOT NULL,
  `sender` varchar(50) DEFAULT NULL,
  `users_id` varchar(20) DEFAULT NULL,
  `message` text,
  `date` datetime DEFAULT NULL,
  `view` int(5) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `chats`
--

INSERT INTO `chats` (`id`, `sender`, `users_id`, `message`, `date`, `view`) VALUES
(1, 'teacher-student', '1-5', 'Саламатсың ба Ақниет', '2022-01-19 23:05:44', 0),
(2, 'student-teacher', '5-1', 'Саламатсыз ба апай', '2022-01-19 23:05:45', 0),
(3, 'teacher-student', '1-5', 'Ақниет оқушыларға ескертіп айтасын ба келесі дүйсенбі күні бақылау жұмысы болады. Соған дайындалып келсін.', '2022-01-19 23:25:30', 0),
(4, 'student-teacher', '5-1', 'Жақсы апай түсіндім барлығына жеткізем. Рахмет!', '2022-01-19 23:26:35', 0),
(7, 'teacher-student', '1-5', 'Жақсы рахмет саған да!', '2022-01-20 01:49:35', 0),
(9, 'teacher-parent', '1-2', 'fdsfd', '2022-01-22 06:28:33', 0),
(10, 'teacher-student', '1-5', 'Сәлем!', '2022-01-22 08:41:25', 0),
(12, 'student-teacher', '5-1', 'Саламатсыз ба апай!', '2022-01-22 08:47:09', 0),
(13, 'student-teacher', '5-2', 'Саламатсыз ба апай!', '2022-01-22 08:56:35', 0),
(14, 'parent-teacher', '1-1', 'Саламатсыз ба?\n', '2022-02-05 06:44:10', 0),
(15, 'parent-teacher', '1-2', 'Hello world!', '2022-02-05 09:04:47', 0),
(16, 'teacher-student', '2-1', 'Hello world!', '2022-02-05 16:14:24', 0),
(17, 'student-teacher', '1-2', 'пвпе', '2022-02-20 09:44:41', 0),
(18, 'teacher-student', '2-1', 'ыуака', '2022-02-20 09:46:33', 0),
(19, 'parent-teacher', '2-2', 'аыавпва', '2022-02-20 09:48:06', 0),
(20, 'teacher-student', '2-1', 'ававвпа', '2022-02-20 10:16:05', 0),
(21, 'teacher-student', '2-1', 'авпа', '2022-04-17 03:14:01', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `diary`
--
-- Создание: Апр 14 2022 г., 18:15
--

DROP TABLE IF EXISTS `diary`;
CREATE TABLE `diary` (
  `id` int(11) NOT NULL,
  `class` int(11) NOT NULL,
  `w1` varchar(255) DEFAULT NULL,
  `w2` varchar(255) DEFAULT NULL,
  `w3` varchar(255) DEFAULT NULL,
  `w4` varchar(255) DEFAULT NULL,
  `w5` varchar(255) DEFAULT NULL,
  `w6` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `diary`
--

INSERT INTO `diary` (`id`, `class`, `w1`, `w2`, `w3`, `w4`, `w5`, `w6`) VALUES
(1, 5, '1|8:00-9:00||2|9:00-10:00||11|10:00-11:00||13|11:00-12:00', '3|8:00-9:00||3|9:00-10:00||11|10:00-11:00||11|11:00-12:00', '1|8:00-9:00||14|9:00-10:00||12|10:00-11:00||10|11:00-12:00', '2|8:00-9:00||1|9:00-10:00||14|10:00-11:00||13|11:00-12:00', '1|8:00-9:00||3|9:00-10:00||4|10:00-11:00||3|11:00-12:00', '5|8:00-9:00||3|9:00-10:00||12|10:00-11:00||10|11:00-12:00');

-- --------------------------------------------------------

--
-- Структура таблицы `files`
--
-- Создание: Апр 14 2022 г., 18:15
--

DROP TABLE IF EXISTS `files`;
CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `teacher_id` int(11) NOT NULL,
  `classes` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `files`
--

INSERT INTO `files` (`id`, `name`, `teacher_id`, `classes`) VALUES
(6, '/2_754035132951/Almaty.csv', 2, '11;'),
(7, '/2_754035132951/dataregression.csv', 2, '10;'),
(10, '/2_754035132951/titanic_train.csv', 2, '1;2;3;4;5;6;7;8;9;10;11;'),
(12, '/1_010215500123/titanic_train.csv', 1, '1;3;'),
(13, '/1_010215500123/ProceedingsICS1998.pdf', 1, '2;4;'),
(14, '/2_754035132951/titanic.csv', 2, '5;7;'),
(15, '/2_754035132951/Nuriddinov O.docx', 2, '4;6;8;10;');

-- --------------------------------------------------------

--
-- Структура таблицы `parents`
--
-- Создание: Май 07 2022 г., 01:14
--

DROP TABLE IF EXISTS `parents`;
CREATE TABLE `parents` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `patronymic` varchar(50) NOT NULL,
  `iin` varchar(50) NOT NULL,
  `mail` varchar(50) DEFAULT NULL,
  `last_time` datetime DEFAULT NULL,
  `password` varchar(50) NOT NULL,
  `child_id` int(11) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `gender` int(4) NOT NULL DEFAULT '1',
  `child_class` int(3) DEFAULT NULL,
  `pass2` varchar(255) NOT NULL,
  `pass_hash` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `parents`
--

INSERT INTO `parents` (`id`, `firstname`, `lastname`, `patronymic`, `iin`, `mail`, `last_time`, `password`, `child_id`, `phone`, `gender`, `child_class`, `pass2`, `pass_hash`) VALUES
(1, 'Асхатов    ', 'Ислам ', 'Асетович', '700203456235', '', '2022-02-05 09:08:02', 'passw', 4, NULL, 1, 8, '', ''),
(2, 'Мұхтарбай ', 'Сабыржан ', 'Асетұлы', '288987049844', 'Asetuly@gmail.com', '2022-02-20 16:18:02', 'pass321', 1, NULL, 1, 5, '', ''),
(3, 'Кумарова ', 'Назерке ', 'Болатовна', '236405323157', 'Nazerke@gmail.com', NULL, 'pass321', 3, '87771234567', 2, 7, '', ''),
(4, 'Серікова ', 'Ақниет ', 'Ғалымжанқызы', '414423443262', 'Serikova12@gmail.com', NULL, 'pass321', 4, '87771234556', 2, 8, '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `plan`
--
-- Создание: Апр 14 2022 г., 18:15
--

DROP TABLE IF EXISTS `plan`;
CREATE TABLE `plan` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `class` int(11) NOT NULL,
  `file` varchar(255) NOT NULL,
  `subject_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `plan`
--

INSERT INTO `plan` (`id`, `teacher_id`, `class`, `file`, `subject_id`) VALUES
(9, 2, 11, '/2_754035132951/Геометрия_11.pdf', 16),
(11, 2, 5, '/2_754035132951/Математика_5.pdf', 1),
(12, 2, 4, '/2_754035132951/Алгебра_4.pdf', 10),
(13, 2, 9, '/2_754035132951/Геометрия_9.pdf', 16),
(14, 2, 9, '/2_754035132951/Алгебра_9.pdf', 10),
(15, 2, 9, '/2_754035132951/Математика_9.pdf', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `shedule`
--
-- Создание: Апр 14 2022 г., 18:15
-- Последнее обновление: Май 07 2022 г., 08:42
--

DROP TABLE IF EXISTS `shedule`;
CREATE TABLE `shedule` (
  `id` int(11) NOT NULL,
  `time` varchar(255) DEFAULT NULL,
  `d1` varchar(255) DEFAULT NULL,
  `d2` varchar(255) DEFAULT NULL,
  `d3` varchar(255) DEFAULT NULL,
  `d4` varchar(255) DEFAULT NULL,
  `d5` varchar(255) DEFAULT NULL,
  `d6` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `shedule`
--

INSERT INTO `shedule` (`id`, `time`, `d1`, `d2`, `d3`, `d4`, `d5`, `d6`) VALUES
(1, '8:00-9:00', '1-4|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-1|-|', '1-7|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-12|-|', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|'),
(2, '9:00-10:00', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-15|-|', '1-2|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-6|-|', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|'),
(3, '10:00-11:00', '1-2|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-10|-|', '1-3|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-12|-|', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|'),
(4, '11:00-12:00', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-13|-|', '1-4|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-7|-|', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|'),
(5, '12:00-13:00', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-8|-|', '1-1|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-9|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-0|-|9-1|-|10-1|-|11-0|-|'),
(6, '13:00-14:00', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-1|-|9-1|-|10-1|-|11-13|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-12|-|9-1|-|10-1|-|11-8|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-5|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-1|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-4|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-2|-|9-1|-|10-1|-|11-0|-|'),
(7, '14:00-15:00', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-18|-|9-1|-|10-1|-|11-9|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-5|-|9-1|-|10-1|-|11-3|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-8|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-3|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-3|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-3|-|9-1|-|10-1|-|11-0|-|'),
(8, '15:00-16:00', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-16|-|9-1|-|10-1|-|11-7|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-7|-|9-1|-|10-1|-|11-6|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-18|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-17|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-18|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-16|-|9-1|-|10-1|-|11-0|-|'),
(9, '16:00-17:00', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-15|-|9-1|-|10-1|-|11-6|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-6|-|9-1|-|10-1|-|11-5|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-15|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-18|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-14|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-14|-|9-1|-|10-1|-|11-0|-|'),
(10, '17:00-18:00', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-14|-|9-1|-|10-1|-|11-10|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-3|-|9-1|-|10-1|-|11-6|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-11|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-16|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-11|-|9-1|-|10-1|-|11-0|-|', '1-0|-|2-1|-|3-1|-|4-1|-|5-1|-|6-1|-|7-1|-|8-6|-|9-1|-|10-1|-|11-0|-|');

-- --------------------------------------------------------

--
-- Структура таблицы `students`
--
-- Создание: Май 07 2022 г., 01:14
-- Последнее обновление: Май 07 2022 г., 08:52
--

DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `patronymic` varchar(100) NOT NULL,
  `iin` varchar(12) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `class` int(4) NOT NULL,
  `last_time` datetime DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `teachers` varchar(255) NOT NULL,
  `pass2` varchar(255) NOT NULL,
  `pass_hash` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `students`
--

INSERT INTO `students` (`id`, `firstname`, `lastname`, `patronymic`, `iin`, `mail`, `class`, `last_time`, `password`, `teachers`, `pass2`, `pass_hash`) VALUES
(1, 'Бақбергенов', 'Ерлан', 'Төлегенұлы', '050215500123', 'erlan@gmail.com', 8, '2022-05-07 11:52:06', 'pass1', '1-2;6-2;7-2;', '12345', '72db75e90f63a79b27023a596af581c8'),
(2, 'Бердығұл ', 'Әділет ', 'Ықласұлы', '789977711976', 'Berdygul@gmail.com', 6, NULL, 'pass321', '1-2;6-2;7-2;', '12345', '72db75e90f63a79b27023a596af581c8'),
(3, 'Алпысбай ', 'Абылай ', 'Алпамысұлы', '684966326226', 'Alpysbay@gmail.com', 7, '2022-02-05 09:37:24', 'pass321', '1-2;6-2;7-2;', '12345', '72db75e90f63a79b27023a596af581c8'),
(4, 'Төремұратов  ', 'Саламат  ', 'Ғазизұлы', '341434559580', 'Gazizuly@gmail.com', 8, '2022-01-22 14:37:16', 'pass321', '10-1;2-1;6-2;7-2;', '12345', '72db75e90f63a79b27023a596af581c8'),
(5, 'Құламанова ', 'Ақниет', '', '450234880434', 'Akniet@gmail.com', 9, '2022-04-17 07:05:17', 'pass321', '10-1;2-1;1-2;', '12345', '72db75e90f63a79b27023a596af581c8'),
(6, 'User', 'Userlastname', '', '000324500916', 'nuriddin.atabek@gmail.com', 9, NULL, '123456789', '', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `subjects`
--
-- Создание: Апр 14 2022 г., 18:15
--

DROP TABLE IF EXISTS `subjects`;
CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `subjects`
--

INSERT INTO `subjects` (`id`, `name`) VALUES
(1, 'Математика'),
(2, 'Қазақ тілі'),
(3, 'Ағылшын тілі'),
(4, 'Сурет салу'),
(5, 'Орыс тілі'),
(6, 'Информатика'),
(7, 'Еңбек'),
(8, 'Дене шынықтыру'),
(9, 'Қазақ әдебиеті'),
(10, 'Алгебра'),
(11, 'География'),
(12, 'Қазақстан тарихы'),
(13, 'Физика'),
(14, 'Дүниежүзі тарихы'),
(15, 'Химия'),
(16, 'Геометрия'),
(17, 'Сызу'),
(18, 'Биология');

-- --------------------------------------------------------

--
-- Структура таблицы `teachers`
--
-- Создание: Май 07 2022 г., 01:08
--

DROP TABLE IF EXISTS `teachers`;
CREATE TABLE `teachers` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `patronymic` varchar(50) DEFAULT NULL,
  `iin` varchar(12) NOT NULL,
  `mail` varchar(100) DEFAULT NULL,
  `last_time` datetime DEFAULT NULL,
  `password` varchar(100) NOT NULL,
  `subject_id` varchar(100) DEFAULT NULL,
  `class_id` varchar(100) DEFAULT NULL,
  `pass2` varchar(255) NOT NULL,
  `pass_hash` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `teachers`
--

INSERT INTO `teachers` (`id`, `firstname`, `lastname`, `patronymic`, `iin`, `mail`, `last_time`, `password`, `subject_id`, `class_id`, `pass2`, `pass_hash`) VALUES
(1, 'Бақдаулет', 'Жанар', NULL, '010215500123', NULL, '2022-04-17 07:11:33', 'pass321', '10;2;', '1;2;3;4;9;', '', ''),
(2, 'Тегісбаева  ', 'Айзат ', 'Айболқызы', '754035132951', 'Aibolkyzy@gmail.com', '2022-04-17 07:08:45', 'pass111', '1;10;16;', '4;5;6;7;8;9;10;11;', '', ''),
(3, 'Нәби', 'Дарига', 'Сержанқызы', '962311236514', 'dariga@gmail.com', NULL, 'pass123', '2;5;4', '1;2;3;4', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `video_lesson`
--
-- Создание: Апр 14 2022 г., 18:15
--

DROP TABLE IF EXISTS `video_lesson`;
CREATE TABLE `video_lesson` (
  `id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `class` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `video_lesson`
--

INSERT INTO `video_lesson` (`id`, `subject_id`, `class`, `link`) VALUES
(1, 1, '5|6|7|8|9', 'https://www.youtube.com/embed/VGNA74efcP4'),
(2, 1, '5|6|7|8|9', 'https://www.youtube.com/embed/QfV70KuX7bE'),
(3, 13, '11', 'https://www.youtube.com/embed/6Up1HcysnnI'),
(4, 13, '11', 'https://www.youtube.com/embed/d97TB9D3zJI'),
(5, 13, '11', 'https://www.youtube.com/embed/w01sPelNXws'),
(6, 13, '11', 'https://www.youtube.com/embed/UDh1BAOEHbQ'),
(7, 13, '11', 'https://www.youtube.com/embed/m1ev8C3Mz14'),
(8, 13, '11', 'https://www.youtube.com/embed/PszAV6isyFs'),
(9, 13, '11', 'https://www.youtube.com/embed/cMKeTQYJ6KY'),
(10, 15, '9', 'https://www.youtube.com/embed/GlzL1sjwqRY'),
(11, 15, '9', 'https://www.youtube.com/embed/ZFxYFgQX6P8'),
(12, 15, '9', 'https://www.youtube.com/embed/KP29CtGucHE'),
(13, 15, '9', 'https://www.youtube.com/embed/5Luk4FuiAjY'),
(14, 15, '9', 'https://www.youtube.com/embed/pRo1htgEKaY'),
(15, 2, '10', 'https://www.youtube.com/embed/VGNA74efcP4'),
(16, 2, '10', 'https://www.youtube.com/embed/QfV70KuX7bE');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `diary`
--
ALTER TABLE `diary`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `child_id` (`child_id`);

--
-- Индексы таблицы `plan`
--
ALTER TABLE `plan`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `shedule`
--
ALTER TABLE `shedule`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `video_lesson`
--
ALTER TABLE `video_lesson`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `chats`
--
ALTER TABLE `chats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT для таблицы `diary`
--
ALTER TABLE `diary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `parents`
--
ALTER TABLE `parents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT для таблицы `plan`
--
ALTER TABLE `plan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `shedule`
--
ALTER TABLE `shedule`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT для таблицы `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `video_lesson`
--
ALTER TABLE `video_lesson`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `parents`
--
ALTER TABLE `parents`
  ADD CONSTRAINT `parents_ibfk_1` FOREIGN KEY (`child_id`) REFERENCES `students` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
